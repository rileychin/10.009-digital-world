import scipy.constants as c

from math import pi

def deg_to_rad(deg):
    return round(deg * pi / 180 , 5)
 
def rad_to_deg(rad):
    return round(180 * rad / pi , 5)