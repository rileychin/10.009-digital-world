#Cohort qn1
def position_velocity(v0, t):
    g  = 9.81 
    y  = round(( v0 * t ) - ( 1/2 * g * t**2 ) , 2 )
    dy = round(( v0 ) - ( g * t ) , 2 )
    return y , dy

print(position_velocity(5.0, 10.0))
print(position_velocity(5.0,  0.0))
print(position_velocity(5.0,  5.0))


