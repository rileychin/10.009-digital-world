import RPi.GPIO as GPIO
from time import sleep

# Use the BCM GPIO numbers as the numbering scheme
GPIO.setmode(GPIO.BCM)

# Use GPIO23 for LED 1, GPIO24 for LED 2 and GPIO18 for switch
led = [23, 24]
switch = 25
buttonPressed = False

# Set the GPIO23 and GPIO24 as output.
GPIO.setup(led, GPIO.OUT)

# Set the GPIO18 as input with a pull-down resistor.
GPIO.setup(switch, GPIO.IN, GPIO.PUD_DOWN)


def blink(gpio_number, duration):
    global buttonPressed
    while buttonPressed == True:
        GPIO.output(gpio_number,GPIO.HIGH)
        sleep(duration)
        GPIO.output(gpio_number,GPIO.LOW)
        sleep(duration)
        if buttonPressed == True:
            break
    while buttonPressed == False:
        GPIO.output(gpio_number,GPIO.HIGH)
        sleep(duration)
        GPIO.output(gpio_number,GPIO.LOW)
        sleep(duration)
        if buttonPressed== False:
            break

    '''This function takes in two input: gpio_number and duration. The
    gpio_number specifies the GPIO number which the LED (to be blinked) is
    connected to. The duration is the blink interval in seconds.'''

    # Write your code here


while True:
    
    if GPIO.input(switch)==GPIO.HIGH:
        buttonPressed=True
        GPIO.output(led[0],GPIO.LOW)
        blink(led[1],1)
    elif GPIO.input(switch)==GPIO.LOW:
        buttonPressed=False
        GPIO.output(led[1],GPIO.LOW)
        blink(led[0],1)# Check whether the switch is closed or opened. When the switch is closed,
    # turn off the LED at GPIO24 and blink the LED at GPIO23. When the switch
    # is opened, turn off the LED at GPIO23 and blink the LED at GPIO24. The
    # blink interval should be 1 second.

    # Write your code here

