from kivy.app import App
from kivy.uix.label import Label


class AlternateApp(App):

    def build(self):
        pass

    def alternate(self, instance, touch):
        pass


myapp = AlternateApp()
myapp.run()
